import pandas as pd
import mysql.connector
pd.options.mode.chained_assignment=None
#from Base_Temporal import Temporal_Bloqueo
from temporal_multiples import Temporal_Bloqueo
from parametros import tabla_temporal
from parametros import usuario_mysql
from parametros import password_mysql
from parametros import base
from parametros import ip_mysql


def eliminar_alertas(Desbloqueados, conn_test):

    Temporal_Eliminar = Temporal_Bloqueo(conn_test)
    # import pandas as pd
    # df = pd.DataFrame()
    # df['Documento_Fraude911'] = ['1022357958', '52968612']
    # df['Fecha_Fraude911'] = pd.to_datetime(['2023-03-23 15:12:56','2023-03-23 15:12:56'])
    eliminar=Desbloqueados




    Documentos_a_Eliminar = Temporal_Eliminar.merge(eliminar, left_on="Documento", right_on="Documento_Fraude911",how='inner')
    Documentos_a_Eliminar['Fecha_Fraude911'] = pd.to_datetime(Documentos_a_Eliminar['Fecha_Fraude911'])
    Documentos_a_Eliminar['HoraAlerta'] = pd.to_datetime(Documentos_a_Eliminar['HoraAlerta'])

    Documentos_a_Eliminar['diferencia'] = Documentos_a_Eliminar['Fecha_Fraude911'] - Documentos_a_Eliminar['HoraAlerta']
    Documentos_a_Eliminar['resultado'] = Documentos_a_Eliminar['diferencia'].apply(lambda x: 0 if x.total_seconds() > 0 else 1)

    Documentos_a_Eliminar = Documentos_a_Eliminar.loc[Documentos_a_Eliminar['resultado'] ==0]
    Documentos_eliminar_final = Documentos_a_Eliminar['Documento'].tolist()

    documento_str = ','.join(str(d) for d in Documentos_eliminar_final)

    #documento_buscado = '1075600700'
    #filas_seleccionadas = Temporal_Eliminar.loc[Temporal_Eliminar['Documento'].eq(documento_buscado)]
    # table_name = 'test_temporal'

    # Crea un cursor para interactuar con la base de datos

    # conn_mysql= conexion_mysql()
    # cursor = conn_mysql.cursor()
    # consulta = "DELETE FROM test_temporal WHERE Documento IN %s"
    # cursor.execute(consulta, (Documentos_eliminar_final,))
#######################################################################
    # Conectar a la base de datos


    # Establecer la conexión a la base de datos
    conexion = mysql.connector.connect(
       host=ip_mysql, #192.168.118.57
      # host="192.168.118.57",
      user=usuario_mysql,
      password=password_mysql,
      database=base,
    )



    # Verificar si hay documentos para eliminar
    if Documentos_eliminar_final:
        cursor = conexion.cursor()
        sql = f"DELETE FROM {tabla_temporal} WHERE Documento IN ({documento_str})"
        cursor.execute(sql)
        conexion.commit()
        print("Documentos eliminados")
        conexion.close()
    else:
        print("No hay documentos para eliminar.")

#######################################################################
    # if conn_mysql is not None:
    #     # Crear el objeto Table
    #     metadata = sqlalchemy.MetaData()
    #     mytable = sqlalchemy.Table(table_name, metadata, autoload_with=conn_mysql)

    #     # Crear la consulta de eliminación con la condición de in
    #     # valores a eliminar
    #     delete_query = mytable.delete().where(mytable.c.Documento.in_(Documentos_eliminar_final))

    #     # Ejecutar la consulta de eliminación
    #     conn_mysql.execute(delete_query)
