


# ## producción

# # paramaetros generales
# usuario_400 = 'UsrFraudes'
# password_400 = ''  # solicitar a TI en el momento del despliegue
# usuario_mysql = 'BLOQ'
# password_mysql ='xcDT7936yBQp'
# base = 'Alertamientos'
# tabla_temporal = 'Alertamientos.Bloqueo_preventivo'
# tabla_historica = 'Alertamientos.Bloqueo_preventivo_historico'
# tabla_historica_alerta = 'Alertamientos.historico_alerta_fondos'
# temporal = 'Bloqueo_preventivo'
# historico = 'Bloqueo_preventivo_historico'
# historico_alerta = 'historico_entradas_soluciones_en_linea'
# ip_mysql='192.168.118.57'
# ip_400 = '192.168.60.152:49505'
# # reemplazar archivo FACypherManager_Variables.py del BK

# # servidor:192.168.107.28

# # copiar parametros de alguna alerta de producción


# DESARROLLO

usuario_400 = 'FINANDINA\josgom' #
password_400 = 'Messi20241010'  #
usuario_mysql = 'josgom'
password_mysql ='Jose05'
base = 'test'
tabla_temporal = 'test.Bloqueo_preventivo'
tabla_historica = 'test.Bloqueo_preventivo_historico'
tabla_historica_alerta = 'test.historico_nequi'
temporal = 'Bloqueo_preventivo'
historico = 'Bloqueo_preventivo_historico'
historico_alerta = 'historico_nequi'
ip_mysql='192.168.79.158'
ip_400 = '192.168.60.152:49505'
