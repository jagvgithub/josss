
import pandas as pd
from sqlalchemy import text

def obtener_alertas_numerocuenta(Alertas, conn, chunk_size=100):
    documentos = Alertas['Documento'].unique()

    # Split the list of documents into chunks
    document_chunks = [documentos[i:i+chunk_size] for i in range(0, len(documentos), chunk_size)]

    # Initialize an empty DataFrame to store the results
    ALERTAS_NUMEROCUENTA = pd.DataFrame()

    for chunk in document_chunks:
        documentos_con_comillas = [f"''{doc}''" for doc in chunk]
        documentos_coma_separada = ','.join(documentos_con_comillas)

        # Query for the current chunk
        SQL_QUERY_TDC = f"""
            SELECT * FROM openquery(DB2400_182, 'select A.IDENTCLI,A.NUMDOC,B.CUENTA,C.SUBPRODU,D.DESPROD,E.PAN
        FROM INTTARCRE.SATDACOPE AS A
        LEFT JOIN INTTARCRE.SATBENEFI AS B
        ON A.IDENTCLI = B.IDENTCLI
        LEFT JOIN INTTARCRE.SATCTATAR AS C
        ON B.CUENTA = C.CUENTA
        LEFT JOIN INTTARCRE.SATPRODUC AS D
        ON C.SUBPRODU = D.SUBPRODU
        LEFT JOIN INTTARCRE.SATTARJET AS E
        ON B.CUENTA = E.CUENTA
        where D.DESPROD LIKE ''%DIGITAL%'' AND
        B.FECBAJA = ''0001-01-01''
        AND A.NUMDOC IN ({documentos_coma_separada})')"""

        # Execute the query and append the result to the DataFrame
        IDENTICLI_tDC = pd.read_sql((SQL_QUERY_TDC), conn)
        IDENTICLI_tDC['NUMDOC'] = IDENTICLI_tDC['NUMDOC'].str.strip()
        IDENTICLI_tDC['IDENTCLI'] = IDENTICLI_tDC['IDENTCLI'].str.strip()

        ALERTAS_NUMEROCUENTA = pd.concat([ALERTAS_NUMEROCUENTA, IDENTICLI_tDC], ignore_index=True)

    # Merge and clean as before
    ALERTAS_NUMEROCUENTA = pd.merge(Alertas, ALERTAS_NUMEROCUENTA, left_on='Documento', right_on='NUMDOC', how='left')
    ALERTAS_NUMEROCUENTA = ALERTAS_NUMEROCUENTA.drop(columns=['SUBPRODU', 'DESPROD', 'NUMDOC'], axis=1)

    return ALERTAS_NUMEROCUENTA
