
from parametros import usuario_mysql
from parametros import password_mysql
from parametros import base
from parametros import ip_mysql


# usuario_mysql = usuario_mysql
# password_mysql = password_mysql
# base = base
from sqlalchemy import create_engine
import sqlalchemy
from sqlalchemy.exc import SQLAlchemyError

# def create_engine_connection(user, password, host, database):
#     try:
#         engine = sqlalchemy.create_engine(
#             f'mysql+mysqlconnector://{user}:{password}@{host}/{database}'
#         )
#         print(f"conexion a la base de datos {database} exitosa.")
#         return engine.connect()
#     except SQLAlchemyError as e:
#         print(f"An error occurred while connecting to database '{database}': {str(e)}")
#         return None







# def conexion_test():
#     user='BLOQ'
#     password='xcDT7936yBQp'
#     host='192.168.118.57'
#     database='Alertamientos'
#     conn_test = create_engine_connection(user, password,host,database)

#     return conn_test


# def conexion_fraude():
#     user='BLOQ'
#     password='xcDT7936yBQp'
#     host='192.168.118.57'
#     database='BFFR4UD'
#     conn_fraude = create_engine_connection(user, password,host,database)

#     return conn_fraude





# def escritura_mysql():
#     user='BLOQ'
#     password='xcDT7936yBQp'
#     host='192.168.118.57'
#     database='Alertamientos'
#     engine = create_engine(f'mysql+mysqlconnector://{user}:{password}@{host}/{database}')
#     return engine

def create_engine_connection(user, password, host, database):
    try:
        engine = sqlalchemy.create_engine(
            f'mysql+mysqlconnector://{user}:{password}@{host}/{database}'
        )
        print(f"conexion a la base de datos {database} exitosa.")
        return engine.connect()
    except SQLAlchemyError as e:
        print(f"An error occurred while connecting to database '{database}': {str(e)}")
        return None



def conexion_test():
    user = usuario_mysql
    password=password_mysql
    host= ip_mysql
    database=base
    conn_test = create_engine_connection(user, password,host,database)

    return conn_test


def conexion_fraude():
    user = usuario_mysql
    password=password_mysql
    host=ip_mysql
    database='BFFR4UD'
    conn_fraude = create_engine_connection(user, password,host,database)

    return conn_fraude





def escritura_mysql():
    user = usuario_mysql
    password=password_mysql
    host=ip_mysql
    database=base
    engine = create_engine(f'mysql+mysqlconnector://{user}:{password}@{host}/{database}')
    return engine


