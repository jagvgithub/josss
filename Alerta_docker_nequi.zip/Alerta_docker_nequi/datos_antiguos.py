
####################################

import pandas as pd
from sqlalchemy import text


def datos_antiguos(Documento_Con_Celular_Correo,conn_fraude):
    Documentos = Documento_Con_Celular_Correo
    documentos_con_comillas = Documentos['Documento'].apply(lambda x: f"'{x}'")
    documentos_coma_separada = ','.join(documentos_con_comillas)
    
    
    sql_query_datos_antiguos = f"""
    SELECT CUSSNR as documento,CUEMA1 as correo_antiguo, CUCLPH as numero_antiguo, JOTSTP FROM BFFR4UD.JOURCUP WHERE CUSSNR IN ({documentos_coma_separada}) AND JOENTT = 'UB'  
    """
    
    datos_antiguos=pd.read_sql(text(sql_query_datos_antiguos),conn_fraude )
    
    datos_antiguos['JOTSTP'] = pd.to_datetime(datos_antiguos['JOTSTP'])
    
    datos_antiguos = datos_antiguos.sort_values(by=['documento', 'JOTSTP'])
    datos_antiguos = datos_antiguos.drop_duplicates(subset='documento', keep='first')
    datos_antiguos['documento']=datos_antiguos['documento'].astype(str)
    documentos_con_datos_antiguos= pd.merge(Documento_Con_Celular_Correo,datos_antiguos, left_on='Documento',right_on='documento',how='left')
    documentos_con_datos_antiguos=documentos_con_datos_antiguos.drop(columns=['documento','JOTSTP'],axis=1)
    
    
    return documentos_con_datos_antiguos
