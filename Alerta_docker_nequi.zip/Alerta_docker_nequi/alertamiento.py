import pandas as pd
import numpy as np
import datetime
from sqlalchemy import text
import pandas as pd
from datetime import datetime, timedelta
from parametros import tabla_historica_alerta
from parametros import base



def alertas(datos_disposito_vinculado,conn_test,conn_riesgo):

    def parametros(conn_test):
         if not conn_test:
             print("No se pudo establecer conexión con la base de datos fabogreport ")
             return None

         query_parametros = f''' SELECT * FROM {base}.parametros_alertas'''
         try:
             base_parametros = pd.read_sql(text(query_parametros),conn_test )
         except Exception as e:
             print(f"Error al ejecutar la consulta a la tabla de categorías: {e}")
             return None

         return base_parametros


    def agregar_cero(valor):
            if len(valor) == 5:
                return '0' + valor
            else:
                return valor

    def agregar_20(valor):
        if len(valor) == 6:
            return valor[:4] + '20' + valor[4:]
        else:
            return valor

    def convertir_a_fecha(cadena):
        return pd.to_datetime(cadena, format='%d%m%Y').strftime('%Y/%m/%d')


    parametro=pd.DataFrame(parametros(conn_test))

    # list(parametro.columns)
    # definicion de parámetros

    who_is_who = int(parametro['who_is_who_alerta_neq_transf_ach'][0])

    tiempo_transaccionalidad = int(parametro['apertura_alerta_neq_transf_ach'][0])

    apertura = (datetime.now()- timedelta(days=tiempo_transaccionalidad)).strftime('%Y-%m-%d')
    datos_disposito_vinculado['FechaApertura'] = datos_disposito_vinculado['FechaApertura'].astype(int).astype(str).apply(agregar_cero)
    datos_disposito_vinculado['FechaApertura'] = datos_disposito_vinculado['FechaApertura'].apply(agregar_20)
    datos_disposito_vinculado['FechaApertura'] = datos_disposito_vinculado['FechaApertura'].apply(convertir_a_fecha)
    datos_disposito_vinculado['FechaApertura'] = pd.to_datetime(datos_disposito_vinculado['FechaApertura'])
    # Filtra registros desde hoy hasta hace 6 meses
    datos_disposito_vinculado = datos_disposito_vinculado[(datos_disposito_vinculado['FechaApertura'] >= apertura) ]
    # datos_disposito_vinculado['NumeroCuenta'] = datos_disposito_vinculado['NumeroCuenta'].apply(lambda x: '{:.0f}'.format(x))
    # datos_disposito_vinculado['Documento'] = datos_disposito_vinculado['Documento'].apply(lambda x: '{:.0f}'.format(x))


    datos_disposito_vinculado = datos_disposito_vinculado[(datos_disposito_vinculado['CaracterTransaccion']=='Entrada') & ((datos_disposito_vinculado['CodigoTipoProducto']==34) |(datos_disposito_vinculado['CodigoTipoProducto']==23) ) ]



    alerta_cantidad_dispositivos_vinculados = datos_disposito_vinculado

    alerta_cantidad_dispositivos_vinculados["HoraAlerta"] = datetime.now()



    who_is_who_concesionarios = f'''select  p.numeroidentificacion as Documento,s.FechaSolicitud as Fecha from [AWPRODBZL02,51734].[FinandinaBPMPro].[dbo].[Participante] p
            inner join [AWPRODBZL02,51734].[FinandinaBPMPro].[dbo].Solicitud s on s.idSolicitud = p.Solicitud
            where sDescrEnrolamientoASISA ='CEDULA ORIGINAL OK'
            and s.FechaSolicitud >= getdate()-{who_is_who}
                    '''

    who_is_who_concesionarios = pd.read_sql(who_is_who_concesionarios,conn_riesgo)


    who_is_who_cet = f'''select  p.snumeroidentificacion as Documento,d.dfechadesolicitud as Fecha   from [AWPRODBZL02,51734].[FinandinaBPMPro].[dbo].M_Participantes p
            inner join [AWPRODBZL02,51734].[FinandinaBPMPro].[dbo].M_PersonaNatural_FF PN on pn.idM_PersonaNatural_FF = p.idM_PersonaNatural
            inner join [AWPRODBZL02,51734].[FinandinaBPMPro].[dbo].M_DatosConsultaWhoIsWhoF  who on who.idM_DatosConsultaWhoIsWhoF = PN.M_DatosConsultaWhoIsWho
            inner join [AWPRODBZL02,51734].[FinandinaBPMPro].[dbo].M_Solicitud_VFF S on S.idM_Solicitud_VFF = p.M_Solicitud_VFF
            inner join [AWPRODBZL02,51734].[FinandinaBPMPro].[dbo].DatosGenerales  d on d.idDatosGenerales = s.idDatosGenerales
            where who.sdescripcionrespuesta = 'CEDULA ORIGINAL OK'
            and d.dfechadesolicitud >= getdate() -{who_is_who}
                        '''

    who_is_who_cet = pd.read_sql(who_is_who_cet,conn_riesgo)
    consolidado_who_is_who = pd.concat([who_is_who_concesionarios,who_is_who_cet],axis=0)
    consolidado_who_is_who = consolidado_who_is_who.groupby('Documento')['Fecha'].max().reset_index()

    alerta_cantidad_dispositivos_vinculados = alerta_cantidad_dispositivos_vinculados[~alerta_cantidad_dispositivos_vinculados['Documento'].isin(consolidado_who_is_who['Documento'])]


    def historico(conn_test):
        if not conn_test:
            print("No se pudo establecer conexión con la base de datos fabogreport ")
            return None

        query_reports = f''' SELECT DISTINCT Documento FROM {tabla_historica_alerta}'''



        try:
            base_historico = pd.read_sql(text(query_reports),conn_test )
        except Exception as e:
            print(f"Error al ejecutar la consulta a la tabla de categorías: {e}")
            return None

        return base_historico


    Base_Historico=historico(conn_test)


    alerta_cantidad_dispositivos_vinculados = alerta_cantidad_dispositivos_vinculados[~alerta_cantidad_dispositivos_vinculados['Documento'].isin(Base_Historico['Documento'])]



    return alerta_cantidad_dispositivos_vinculados
