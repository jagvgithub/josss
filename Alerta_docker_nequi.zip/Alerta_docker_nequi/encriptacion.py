# -*- coding: utf-8 -*-
"""
Created on Mon Apr 10 10:33:39 2023

@author: josgom
"""





import datetime
import pandas as pd

import requests
import json
from FACypherManager_Variables import *


def encriptar_tarjetas(df):
    day = datetime.datetime.today().strftime('%Y-%m-%d')
    headers = {"Content-Type": "application/json"}

    
    for index, row in df.iterrows():
        # Obtener el número de tarjeta de la fila actual
        
        PAN = row['PAN']
        
        # Verificar si PAN no es nulo
        if not pd.isnull(PAN):
            api_url_StringToHex = parametros()[0]
            paramPAN = {"hexstring": PAN}
            response_hex = requests.post(api_url_StringToHex, data=json.dumps(paramPAN), headers=headers)
            response_hex.json()
            api_url_ConvertDateToTimestamp = parametros()[1]
            paramFecha = {"fecha": day}
            response_DateToTimestamp = requests.post(api_url_ConvertDateToTimestamp, data=json.dumps(paramFecha), headers=headers)
            api_url_EncryptTripleDES = parametros()[2]
            param_EncryptTripleDES = {"key": str(response_DateToTimestamp.json()), "toEncrypt": str(response_hex.json())}
            response_EncryptTripleDES = requests.post(api_url_EncryptTripleDES, data=json.dumps(param_EncryptTripleDES), headers=headers)
            encriptado=response_EncryptTripleDES.text
            df.at[index, 'PAN'] = encriptado

    return df




        



