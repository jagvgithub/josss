
import pandas as pd
from parametros import temporal
from parametros import historico
from parametros import historico_alerta



def procesar_alertas(tabla, engine, Temporal):
    # Obtener los datos de la tabla

    #inmunes=Desbloqueados
    # Alertas=alertados_con_datos_antiguos.tail()
    Alertas = tabla
    #inmunes = pd.DataFrame(inmunes)
    # Filtrar los datos para quitar los documentos en la tabla temporal
    Alertas_Temporal = Alertas[~Alertas['Documento'].isin(Temporal['Documento'])]

    # Alertas_Temporal = Alertas_Temporal[~Alertas_Temporal['Documento'].isin(historica['Documento'])]
    #Alertas_Temporal=Alertas_Temporal[~Alertas_Temporal['Documento'].isin(inmunes['Documento'])]

    # Filtrar los datos para quitar los documentos en la tabla temporal
    Alerta_Historico = Alertas_Temporal[~Alertas_Temporal['Documento'].isin(Temporal['Documento'])]
    #Alerta_Historico = Alerta_Historico[~Alerta_Historico['Documento'].isin(inmunes['Documento'])]


    # Escribir los datos filtrados en la tabla "Test" en la base de datos
    alertaentradas = Alertas_Temporal

    Alertas_Temporal['Alertamiento']='Entradas_Rc_PSE_Transfiya_TRANSF._INTERBANCARIA_APPPERS'
    # Alertas_Temporal['Alertamiento']='PRUEBAS_RPA'
    alertaentradas = alertaentradas.drop('Alertamiento', axis=1)
    Alertas_columnas_filtradas= Alertas_Temporal[['Documento','HoraAlerta', 'IDENTCLI', 'CUENTA', 'PAN', 'CORREO_NUEVO', 'NUMERO_NUEVO', 'NOMBRE_COMPLETO', 'primer_nombre', 'correo_antiguo', 'numero_antiguo', 'Alertamiento']]
    # Alertas_columnas_filtradas= Alertas_Temporal[['NumeroCuenta','Documento','HoraAlerta', 'IDENTCLI', 'CUENTA', 'PAN', 'CORREO_NUEVO', 'NUMERO_NUEVO', 'NOMBRE_COMPLETO', 'primer_nombre', 'correo_antiguo', 'numero_antiguo', 'Alertamiento']]
    # Alertas_columnas_filtradas['correo_antiguo'] = Alertas_columnas_filtradas['CORREO_NUEVO']
    # Alertas_columnas_filtradas['numero_antiguo'] = Alertas_columnas_filtradas['NUMERO_NUEVO']
    # Alertas_columnas_filtradas = Alertas_columnas_filtradas.drop('NumeroCuenta', axis=1)


    # copia2 = Alertas_columnas_filtradas

    # copia=Alertas_columnas_filtradas




    # Alertas_columnas_filtradas['NUMERO_NUEVO'] = Alertas_columnas_filtradas['NUMERO_NUEVO'].apply(lambda x: "{:.0f}".format(x))
    # Alertas_columnas_filtradas['numero_antiguo'] = Alertas_columnas_filtradas['numero_antiguo'].apply(lambda x: "{:.0f}".format(x))
    # Alertas_columnas_filtradas = Alertas_columnas_filtradas.drop('NumeroCuenta', axis=1)


    Alertas_columnas_filtradas = Alertas_columnas_filtradas.groupby('Documento').first().reset_index()



    Alertas_columnas_filtradas.to_sql(temporal,con=engine,if_exists='append',index=False)

    # Escribir los datos filtrados en la tabla "Test_Historico" en la base de datos
    Alertas_columnas_filtradas.to_sql(historico,con=engine,if_exists='append',index=False)

    alertaentradas.to_sql(historico_alerta,con=engine,if_exists='append',index=False)

    return Alertas_Temporal,Alerta_Historico,alertaentradas
