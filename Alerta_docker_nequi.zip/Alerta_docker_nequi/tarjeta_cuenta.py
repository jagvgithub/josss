# -*- coding: utf-8 -*-
"""
Created on Tue Feb 21 09:28:22 2023

@author: jesalvc
"""
from sqlalchemy import text
import pandas as pd
import numpy as np

# ALERTAS_NUMEROCUENTA=numero_identificacion
def obtener_alertas_numero_cuenta(ALERTAS_NUMEROCUENTA, conn_riesgo):
    # ALERTAS_NUMEROCUENTA=numero_identificacion
   numero_cuenta_con_comillas = ALERTAS_NUMEROCUENTA['IDENTCLI'].apply(lambda x: f"''{x}''")
   # numero_cuenta_con_comillas = Documentos_Con_Cuenta['IDENTCLI'].apply(lambda x: f"''{x}''")
   numero_cuenta_coma_separada = ','.join(numero_cuenta_con_comillas)

  
   #### NUMERO DE CUENTA##################################################################################################
   SQL_QUERY_CUENTA = f"""
   SELECT * FROM openquery(DB2400_182, 'SELECT IDENTCLI, CUENTA FROM INTTARCRE.SATBENEFI WHERE IDENTCLI IN ({numero_cuenta_coma_separada}) and FECBAJA = ''0001-01-01'' ')
   """
   CUENTA_tDC = pd.read_sql((SQL_QUERY_CUENTA),conn_riesgo )
   CUENTA_tDC['CUENTA']=CUENTA_tDC['CUENTA'].str.strip()
   CUENTA_tDC['IDENTCLI']=CUENTA_tDC['IDENTCLI'].str.strip()
   CUENTA_tDC=CUENTA_tDC.dropna()
   
   numero_subproducto_con_comillas = CUENTA_tDC['CUENTA'].apply(lambda x: f"''{x}''")
   # numero_cuenta_con_comillas = Documento_Con_Numero_Cuenta['IDENTCLI'].apply(lambda x: f"''{x}''")
   numero_subproducto_coma_separada = ','.join(numero_subproducto_con_comillas)
   
   
   # sql_query_subproducto = f"""
   #  SELECT * FROM openquery(DB2400_182, 'SELECT CUENTA as cuentasat,SUBPRODU FROM INTTARCRE.SATCTATAR WHERE CUENTA IN ({numero_subproducto_coma_separada}) ')
   #  """
   # subproducto = pd.read_sql((sql_query_subproducto),conn_riesgo )
   # subproducto['CUENTASAT']=subproducto['CUENTASAT'].str.strip()
   # subproducto['SUBPRODU']=subproducto['SUBPRODU'].str.strip()
   # subproducto=subproducto.dropna()
   try:
    sql_query_subproducto = f"""
       SELECT * FROM openquery(DB2400_182, 'SELECT CUENTA as cuentasat,SUBPRODU FROM INTTARCRE.SATCTATAR WHERE CUENTA IN ({numero_subproducto_coma_separada}) ')
       """
    subproducto = pd.read_sql((sql_query_subproducto),conn_riesgo )
    subproducto['CUENTASAT']=subproducto['CUENTASAT'].str.strip()
    subproducto['SUBPRODU']=subproducto['SUBPRODU'].str.strip()
    subproducto=subproducto.dropna()
   except:
    subproducto = pd.DataFrame({'CUENTASAT': [np.nan], 'SUBPRODU': [np.nan]})
   
    
     # Inicializar subproducto como un DataFrame vacío

   # new_row = {'CUENTASAT': np.nan, 'SUBPRODU': np.nan}  # Crear la nueva fila como un diccionario

   # subproducto = subproducto.append(new_row, ignore_index=True)  
  
   alerta_subproducto = pd.merge(CUENTA_tDC,subproducto , left_on='CUENTA', right_on='CUENTASAT', how='left')

    
   subproducto_con_comillas = alerta_subproducto['SUBPRODU'].apply(lambda x: f"''{x}''")
   subproducto_coma_separada = ','.join(subproducto_con_comillas)
   
    
     
   
   try:
       sql_virtual_digital = f"""
       SELECT * FROM openquery(DB2400_182, 'SELECT DESPROD, SUBPRODU FROM INTTARCRE.SATPRODUC WHERE SUBPRODU IN ({subproducto_coma_separada}) ')
       """
       virtual_digital = pd.read_sql((sql_virtual_digital),conn_riesgo)
       virtual_digital['DESPROD']=virtual_digital['DESPROD'].str.strip()
       virtual_digital['SUBPRODU']=virtual_digital['SUBPRODU'].str.strip()
   except:
       virtual_digital = pd.DataFrame({'DESPROD': [np.nan], 'SUBPRODU': [np.nan]})                                        
       
         
   
   
   alerta_virtual_digital = pd.merge(alerta_subproducto,virtual_digital , left_on='SUBPRODU', right_on='SUBPRODU', how='left')

   alerta_virtual_digital['DESPROD'] = alerta_virtual_digital['DESPROD'].astype(str)
   alerta_virtual_digital = alerta_virtual_digital[alerta_virtual_digital['DESPROD'].str.contains('DIGITAL', case=False)]
   
   
   
   alerta_virtual_digital= alerta_virtual_digital.drop(columns=['CUENTASAT','SUBPRODU','DESPROD'], axis=1)
   
   
   
   
   
   ALERTAS_NUMEROTDC = pd.merge(ALERTAS_NUMEROCUENTA,alerta_virtual_digital , left_on='IDENTCLI', right_on='IDENTCLI', how='left')
   
   # ALERTAS_NUMEROTDC = pd.merge(Documento_Con_Numero_Cuenta,CUENTA_tDC , left_on='IDENTCLI', right_on='IDENTCLI', how='left')
   
  
   
   


  

   return ALERTAS_NUMEROTDC