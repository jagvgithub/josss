
# PRODUCCION
# def parametros():

#     """
#     URL API StringToHex
#     """
#     api_StringToHex = "http://192.168.125.51:8891/FACypherManager/StringToHex"

#     """
#     URL API ConvertDateToTimestamp
#     """
#     api_ConvertDateToTimestamp = "http://192.168.125.51:8891/FACypherManager/ConvertDateToTimestamp"


#     """
#     URL API EncryptTripleDES
#     """
#     api_EncryptTripleDES = "http://192.168.125.51:8891/FACypherManager/EncryptTripleDES"


#     return(api_StringToHex, api_ConvertDateToTimestamp, api_EncryptTripleDES)



# DESARROLLO

def parametros():

    """
    URL API StringToHex
    """
    api_StringToHex = "http://192.168.79.25:8888/FACypherManager/StringToHex"

    """
    URL API ConvertDateToTimestamp
    """
    api_ConvertDateToTimestamp = "http://192.168.79.25:8888/FACypherManager/ConvertDateToTimestamp"


    """
    URL API EncryptTripleDES
    """
    api_EncryptTripleDES = "http://192.168.79.25:8888/FACypherManager/EncryptTripleDES"
    
    
    return(api_StringToHex, api_ConvertDateToTimestamp, api_EncryptTripleDES)






