import pandas as pd
from sqlalchemy import text
from datetime import datetime, timedelta
from parametros import base
import numpy as np


# def dispositivo(conn_riesgo,conn_test):
#     # def parametros(conn_test):
#     #     if not conn_test:
#     #         print("No se pudo establecer conexión con la base de datos fabogreport")
#     #         return None

#     #     query_parametros = f'''SELECT * FROM {base}.parametros_alertas'''
#     #     try:
#     #         base_parametros = pd.read_sql(text(query_parametros), conn_test)
#     #     except Exception as e:
#     #         print(f"Error al ejecutar la consulta a la tabla de categorías: {e}")
#     #         return None

#     #     return base_parametros

#     # parametro = pd.DataFrame(parametros(conn_test))
#     # tiempo_trx = int(parametro['apertura_alerta_neq_transf_ach'][0])

#     if not conn_riesgo:
#         print("No se pudo establecer conexión con la base de datos en línea de transacciones de ahorro")
#         return None

#     # Obtén la fecha y hora actuales
#     fecha_actual = datetime.now()

#     # Resta 30 días a la fecha actual
#     fecha_ayer = fecha_actual - timedelta(days=30)

#     # Convierte la fecha de hace 30 días al formato juliano
#     fecha_juliana_ayer = fecha_ayer.strftime("%Y%j")

#     query_reports = f'''
#     SELECT
#         CAST(CUSSNR AS VARCHAR(255)) AS Documento,
#         CAST(CUX1CS AS VARCHAR(255)) AS IdAS400Cliente,
#         CAST(DHACCT AS VARCHAR(255)) AS NumeroCuenta,
#         DMDOPN AS FechaApertura,
#         DMSTAT AS EstadoCuenta,
#         DHSER AS NumeroSerieCheque,
#         DHTYP AS TipoCuenta,
#         DHTYPE AS CodigoTipoProducto,
#         CFPRNM AS DescripcionTipoProducto,
#         CAST(DHEFF AS VARCHAR(255)) AS FechaTransaccionEfectiva,
#         DHDATE AS FechaPublicacion,
#         DHDSCA AS RegistroAsociadoTransaccion,
#         DHBTSQ AS CodigoSecuenciaBatch,
#         DHITC AS CodigoInternoTransaccion,
#         DHOTC AS CodigoTransaccion1,
#         DHOTC2 AS CodigoTransaccion2,
#         DHTLTR AS CodigoTransaccionTeller,
#         DHDRCR AS CodigoDebitoCredito,
#         CASE WHEN DHDRCR >= 6 THEN 'Salida'
#              ELSE 'Entrada'
#         END AS CaracterTransaccion,
#         DHDSC1 AS DescripcionTransaccional1,
#         DHDSC2 AS DescripcionTransaccional2,
#         DHDSC3 AS DescripcionTransaccional3,
#         CFTCD2 AS DescripcionTransaccional4,
#         DHAMT AS MontoTransaccion,
#         DHWHTY AS MontoRetenido,
#         DHNBR AS NumeroTransaccionDia,
#         DHSTRN AS FuenteTransaccion,
#         DHBRCH AS CodigoSucursal,
#         CFBRNM AS DescripcionSucursal
#     FROM OPENQUERY(DB2400_182, '
#         SELECT
#             TransaccionesAhorro.DHACCT,
#             TransaccionesAhorro.DHSER,
#             TransaccionesAhorro.DHTYP,
#             TransaccionesAhorro.DHTYPE,
#             TransaccionesAhorro.DHEFF,
#             TransaccionesAhorro.DHDATE,
#             TransaccionesAhorro.DHDSCA,
#             TransaccionesAhorro.DHBTSQ,
#             TransaccionesAhorro.DHITC,
#             TransaccionesAhorro.DHOTC,
#             TransaccionesAhorro.DHOTC2,
#             TransaccionesAhorro.DHTLTR,
#             TransaccionesAhorro.DHDRCR,
#             TransaccionesAhorro.DHSTRN,
#             TransaccionesAhorro.DHBRCH,
#             TransaccionesAhorro.DHAMT,
#             TransaccionesAhorro.DHWHTY,
#             TransaccionesAhorro.DHNBR,
#             Ahorro.DMSTAT,
#             Ahorro.DMDOPN,
#             TransaccionesDescritas.DHDSC1,
#             TransaccionesDescritas.DHDSC2,
#             TransaccionesDescritas.DHDSC3,
#             CatalogoTransacciones.CFTCD2,
#             CatalogoProducto.CFPRNM,
#             CatalogoSucursales.CFBRNM,
#             Enlace.CUX1CS,
#             Cliente.CUSSNR
#         FROM BNKPRD01.TAP00501 AS TransaccionesAhorro
#         LEFT JOIN BNKPRD01.TAP002 AS Ahorro
#             ON TransaccionesAhorro.DHACCT = Ahorro.DMACCT
#         LEFT JOIN BNKPRD01.TAP020 AS TransaccionesDescritas
#             ON TransaccionesAhorro.DHACCT = TransaccionesDescritas.DHACCT
#             AND TransaccionesAhorro.DHDATE = TransaccionesDescritas.DHDATE
#             AND TransaccionesAhorro.DHNBR = TransaccionesDescritas.DHNBR
#         LEFT JOIN BNKPRD01.CFP220L3 AS CatalogoTransacciones
#             ON TransaccionesAhorro.DHITC = CatalogoTransacciones.CFTC
#         LEFT JOIN BNKPRD01.CFP210 AS CatalogoProducto
#             ON TransaccionesAhorro.DHTYPE = CatalogoProducto.CFTNBR
#         LEFT JOIN BNKPRD01.CFP102 AS CatalogoSucursales
#             ON TransaccionesAhorro.DHBRCH = CatalogoSucursales.CFBRCH
#         LEFT JOIN (
#             SELECT
#                 CASE
#                     WHEN LEFT(LTRIM(RTRIM(CUX1AC)), 1) <> '9'
#                     THEN RIGHT(LTRIM(RTRIM(CUX1AC)), LENGTH(LTRIM(RTRIM(CUX1AC))) - 1)
#                     ELSE LTRIM(RTRIM(CUX1AC))
#                 END AS CUX1AC,
#                 CUX1CS, CUX1AP, CUXREC, CUXREL, CUX1TY
#             FROM BNKPRD01.CUP009
#             WHERE CUXREL IN (''SOW'', ''JOF'')
#         ) AS Enlace
#             ON CAST(TransaccionesAhorro.DHACCT AS CHAR(30)) = CAST(Enlace.CUX1AC AS CHAR(30))
#         LEFT JOIN BNKPRD01.CUP003 AS Cliente
#             ON Enlace.CUX1CS = Cliente.CUNBR
#         WHERE DHEFF >= ''{fecha_juliana_ayer}''
#     ')'''

#     try:
#         base_reports = pd.read_sql(query_reports, conn_riesgo)
#     except Exception as e:
#         print(f"Error al ejecutar la consulta a la tabla de categorías: {e}")
#         return None

#     return base_reports












def dispositivo(conn_riesgo):
    # def parametros(conn_test):
    #       if not conn_test:
    #           print("No se pudo establecer conexión con la base de datos fabogreport ")
    #           return None

    #       query_parametros = f''' SELECT * FROM {base}.parametros_alertas'''
    #       try:
    #           base_parametros = pd.read_sql(text(query_parametros),conn_test )
    #       except Exception as e:
    #           print(f"Error al ejecutar la consulta a la tabla de categorías: {e}")
    #           return None

    #       return base_parametros
     
    # parametro=pd.DataFrame(parametros(conn_test))
    # tiempo_apertura = int(parametro['apertura_alerta_neq_transf_ach'][0])
    
    
    if not conn_riesgo:
        print("No se pudo establecer conexión con la base de datos en linea de transacciones de ahorro ")
        return None


    # Obtén la fecha y hora actuales
    fecha_actual = datetime.now()

    # Resta un día a la fecha actual
    fecha_ayer = fecha_actual - timedelta(days=0)

    # Convierte la fecha de ayer al formato juliano
    fecha_juliana_ayer = fecha_ayer.strftime("%Y%j")


    query_reports = f'''SELECT
CAST(CUSSNR AS VARCHAR(255)) AS Documento
,CAST(CUX1CS AS VARCHAR(255)) AS IdAS400Cliente
,CAST(DHACCT AS VARCHAR(255)) AS NumeroCuenta
,DMDOPN AS FechaApertura
,DMSTAT AS EstadoCuenta
,DHSER  AS NumeroSerieCheque
,DHTYP  AS TipoCuenta
,DHTYPE AS CodigoTipoProducto
,CFPRNM AS DescripcionTipoProducto
,CAST(DHEFF AS VARCHAR(255)) AS FechaTransaccionEfectiva
,DHDATE AS FechaPublicacion
,DHDSCA AS RegistroAsociadoTransaccion
,DHBTSQ AS CodigoSecuenciaBatch
,DHITC  AS CodigoInternoTransaccion
,DHOTC  AS CodigoTransaccion1
,DHOTC2 AS CodigoTransaccion2
,DHTLTR AS CodigoTransaccionTeller
,DHDRCR AS CodigoDebitoCredito
,CASE WHEN DHDRCR>=6 THEN 'Salida'
ELSE 'Entrada'
END CaracterTransaccion
,DHDSC1 AS DescripcionTransaccional1
,DHDSC2 AS DescripcionTransaccional2
,DHDSC3 AS DescripcionTransaccional3
,CFTCD2 AS DescripcionTransaccional4
,DHAMT  AS MontoTransaccion
,DHWHTY AS MontoRetenido
,DHNBR  AS NumeroTransaccionDia
,DHSTRN AS FuenteTransaccion
,DHBRCH AS CodigoSucursal
,CFBRNM AS DescripcionSucursal
FROM OPENQUERY(DB2400_182,'select TransaccionesAhorro.DHACCT
,TransaccionesAhorro.DHSER
,TransaccionesAhorro.DHTYP
,TransaccionesAhorro.DHTYPE
,TransaccionesAhorro.DHEFF
,TransaccionesAhorro.DHDATE
,TransaccionesAhorro.DHDSCA
,TransaccionesAhorro.DHBTSQ
,TransaccionesAhorro.DHITC
,TransaccionesAhorro.DHOTC
,TransaccionesAhorro.DHOTC2
,TransaccionesAhorro.DHTLTR
,TransaccionesAhorro.DHDRCR
,TransaccionesAhorro.DHSTRN
,TransaccionesAhorro.DHBRCH
,TransaccionesAhorro.DHAMT
,TransaccionesAhorro.DHWHTY
,TransaccionesAhorro.DHNBR
,Ahorro.DMSTAT
,Ahorro.DMDOPN
,TransaccionesDescritas.DHDSC1
,TransaccionesDescritas.DHDSC2
,TransaccionesDescritas.DHDSC3
,CatalogoTransacciones.CFTCD2
,CatalogoProducto.CFPRNM
,CatalogoSucursales.CFBRNM
,Enlace.CUX1CS
,Cliente.CUSSNR
from BNKPRD01.TAP00501 as TransaccionesAhorro
left join BNKPRD01.TAP002 as Ahorro
on TransaccionesAhorro.DHACCT=Ahorro.DMACCT
left join BNKPRD01.TAP020 as TransaccionesDescritas
on TransaccionesAhorro.DHACCT=TransaccionesDescritas.DHACCT and
TransaccionesAhorro.DHDATE=TransaccionesDescritas.DHDATE and
TransaccionesAhorro.DHNBR=TransaccionesDescritas.DHNBR
left join BNKPRD01.CFP220L3 as CatalogoTransacciones
on TransaccionesAhorro.DHITC=CatalogoTransacciones.CFTC
left join BNKPRD01.CFP210 as CatalogoProducto
on TransaccionesAhorro.DHTYPE=CatalogoProducto.CFTNBR
left join BNKPRD01.CFP102 as CatalogoSucursales
on TransaccionesAhorro.DHBRCH=CatalogoSucursales.CFBRCH
left join (select case when left(ltrim(rtrim(CUX1AC)),1)<>9 then right(ltrim(rtrim(CUX1AC)),length(ltrim(rtrim(CUX1AC)))-1)
else ltrim(rtrim(CUX1AC))
end as CUX1AC
,CUX1CS
,CUX1AP
,CUXREC
,CUXREL
,CUX1TY
from BNKPRD01.CUP009
where CUXREL in (''SOW'',''JOF'')) as Enlace
on cast(TransaccionesAhorro.DHACCT as char(30))=cast(Enlace.CUX1AC as char(30))
left join BNKPRD01.CUP003 as Cliente
on Enlace.CUX1CS=Cliente.CUNBR
where  DHEFF>=''{fecha_juliana_ayer}'' ')'''

# where TransaccionesDescritas.DHDSC3 LIKE (''%FONDO%'')

# Descripcion 1
# DHDSC1
#   Rc_PSE
#   Transfiya
#   TRANSF. INTERBANCARIA APPPERS


    try:
        base_reports = pd.read_sql(query_reports,conn_riesgo )
        base_reports['flag'] = np.where(base_reports['DescripcionTransaccional1'].str.contains(r'Rc_PSE|Transfiya|TRANSF\. INTERBANCARIA APPPERS', case=False, na=False), 1, 0)
        base_reports = base_reports[base_reports['flag']>0]
        base_reports = base_reports.drop(columns={'flag'})
    except Exception as e:
        print(f"Error al ejecutar la consulta a la tabla de categorías: {e}")
        return None

    return base_reports













