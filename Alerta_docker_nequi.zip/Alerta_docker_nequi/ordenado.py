



from FACypherManager_Variables import parametros
from encriptacion import encriptar_tarjetas
from escritura import procesar_alertas
from conexion_mysql import conexion_test
from conexion_mysql import conexion_fraude
from conexion_mysql import escritura_mysql
from conexionreports import  conexion_fabogriesgo
from base_reports import dispositivo
from temporal_multiples import Temporal_Bloqueo
from temporal_multiples import historico_Bloqueo
from alertamiento import alertas
from tercero_numero_cuenta  import obtener_alertas_numerocuenta
from tarjeta_cuenta import obtener_alertas_numero_cuenta
from numero_tarjeta_credito import obtener_alertas_numero_TDC
from datos_nuevos import obtener_celular_correo
from datos_antiguos import datos_antiguos
from sms_911_multiples import Codigo111
from eliminar_alertas_multiples import eliminar_alertas
import datetime
import numpy as np

# Formulas para la ejecución

import warnings
warnings.filterwarnings("ignore")



###1. Primer py, es la conexion a la bases SQL la funcion contiene las conexiones a la siguientes bases de datos
###1.1 conexion_fabogriesgo
###1.2 conexion_fabogsqlclu
###1.3 conexion_QA
# from  Uno_Conexion_a_SQL import conexion_fabogriesgo
#######################################################################################################################



# # paramaetros generales

# usuario_400 = 'FINANDINA\josgom'
# password_400 = 'Messiesinfinito#8'
# usuario_mysql = 'josgom'
# password_mysql ='Jose'
# base = 'test'
# # reemplazar archivo FACypherManager_Variables.py del BK







def main():
    try:


        conn_riesgo = conexion_fabogriesgo()
        conn = conexion_fabogriesgo()
        conn_test =conexion_test()
        conn_fraude=conexion_fraude()
        engine=escritura_mysql()


    except Exception as e:
        print(f"Error al conectarse a la base de datos: {e}")
        return
 ############## Registros con el codigo SMS BloqueoFraudeEstado111 ###########################################
    try:
       Desbloqueados= Codigo111(conn_test)
       # import pandas as pd
       # Desbloqueados['Documento_Fraude911'] = ['1015437279']
       # Desbloqueados['Fecha_Fraude911'] =  pd.to_datetime(['2023-05-18 22:20:56'])

    except Exception as e:
        print(f"Error al obtener los documentos que hicieron who is who : {e}")
        return


    try:
        datos_disposito_vinculado = dispositivo(conn_riesgo)
        # muestra = datos_disposito_vinculado[datos_disposito_vinculado['NumeroCuenta']=='9902337654']
    except Exception as e:
        print(f"Error al obtener la parametrización: {e}")
        return


    try:
        documentos_alertados = alertas(datos_disposito_vinculado,conn_test,conn_riesgo)
        # documentos_alertados=alerta_cantidad_dispositivos_vinculados
        # documentos_alertados['Documento']
        # import numpy as np
        # documentos_alertados['Documento']=np.where(documentos_alertados['Documento']=='1015437279','1002182815',documentos_alertados['Documento'])
        # documentos_alertados['Documento']=np.where(documentos_alertados['Documento']=='80813527','1020836017',documentos_alertados['Documento'])

        # documentos_alertados = documentos_alertados.head(11)
        


    except Exception as e:
        print(f"Error al obtener las alertas: {e}")
        return
    try:
        eliminar_alertas(Desbloqueados,conn_test)
    except Exception as e:
        print(f"Error al obtener los documentos que hicieron who is who : {e}")
        return

    if documentos_alertados.empty:
        print("No hay alertas")
        return

    try:
        numero_identificacion = obtener_alertas_numerocuenta(documentos_alertados,conn_riesgo)
        # numero_identificacion['PAN']='4345511051433276'
    except Exception as e:
        print(f"Error al obtener los documentos con cuenta: {e}")
        return

    # try:
    #     numero_cuenta_tdc = obtener_alertas_numero_cuenta(numero_identificacion,conn_riesgo)
    # except Exception as e:
    #     print(f"Error al obtener los documentos con número de cuenta: {e}")
    #     return

    # try:
    #     numero_tdc = obtener_alertas_numero_TDC(numero_cuenta_tdc,conn_riesgo)
    #     # copia=numero_tdc
    #     # numero_tdc['PAN'] = np.nan

    #     # numero_tdc['PAN'] = numero_tdc['PAN'].apply(lambda x: "{:.0f}".format(x))
    #     # numero_tdc['PAN'] = numero_tdc['PAN'].astype(str)  # Ensure 'PAN' column is of string type
    #     # numero_tdc['PAN'] = numero_tdc['PAN'].astype(float)  # Convert 'PAN' column to float if it's not already
    #     # numero_tdc['PAN'] = numero_tdc['PAN'].apply(lambda x: "{:.0f}".format(x))



    #     # numero_tdc = numero_tdc.head(11)

    # except Exception as e:
    #     print(f"Error al obtener los documentos con número de TDC: {e}")
    #     return

    # numero_identificacion=numero_identificacion.head(10)
        # numero_identificacion['PAN'] = '4345511051433276'
    try:
        encriptacion = encriptar_tarjetas(numero_identificacion)
    except Exception as e:
        print(f"Error al obtener los documentos con número de TDC: {e}")
        return

    try:
       alertados_con_datos = obtener_celular_correo (encriptacion,conn_riesgo)
    except Exception as e:
       print(f"Error al obtener los datos de celular y correo: {e}")
       return

    try:
       alertados_con_datos_antiguos = datos_antiguos(alertados_con_datos,conn_fraude)
       # alertados_con_datos_antiguos = alertados_con_datos_antiguos.DataFrame({'IDENTCLI': [np.nan], 'CUENTA': [np.nan], 'PAN': [np.nan]})
       # alertados_con_datos_antiguos['IDENTCLI'] = [np.nan] * len(alertados_con_datos_antiguos)
       # alertados_con_datos_antiguos['CUENTA']= [np.nan]* len(alertados_con_datos_antiguos)
       # alertados_con_datos_antiguos['PAN']= [np.nan]* len(alertados_con_datos_antiguos)

    except Exception as e:
       print(f"Error al obtener los datos de celular y correo: {e}")
       return




############ Eliminamos registros de la temporal quedan mapeados en la Historica ##########################

###########################################################################################################

########### Leemos la base temporal con los registros anteriores ya eliminados, ahora tenemos que asegurarnos que no vuelvan a entrar################################
    try:
        Temporal = Temporal_Bloqueo(conn_test)
    except Exception as e:
        print(f"Error al obtener la base temporal: {e}")
        return
########################################################################################################################


########### Leemos la base temporal con los registros anteriores ya eliminados, ahora tenemos que asegurarnos que no vuelvan a entrar################################
    # try:
    #     historica = historico_Bloqueo(conn_test)
    # except Exception as e:
    #     print(f"Error al obtener la base temporal: {e}")
    #     return
########################################################################################################################






# La escritura de la tabla de datos funciona de la siguiente manera:
# primero se verifica si los documentos que se quieren registrar ya existen en la tabla temporal.
# Si existen, no se duplicará el registro. En cambio, se verificará si alguno de los documentos ha recibido el SMS "BloqueoFraudeEstado111".
# Si alguno de ellos lo ha recibido, no se escribirá en la tabla de datos con el fin de evitar volver a bloquear a un cliente que ya haya pasado por el proceso de "Who is Who".
# En caso de que los documentos no estén en la tabla temporal ni en la tabla de inmunidad, se procederá a registrar un nuevo registro en la tabla de datos.
# La hora de alerta será la hora de ejecución en la que se está realizando la escritura de la tabla de datos.
# Este proceso se realiza con el fin de mantener actualizada la información en la tabla de datos y evitar bloquear clientes que ya hayan pasado por el proceso de verificación.


    try:
        alertas_temporal, alertas_historico,alertaentradashistorico = procesar_alertas(alertados_con_datos_antiguos, engine, Temporal)


        # Llamar a la función procesar_alertas y guardar los resultados
        # alertas_temporal, alertas_historico = procesar_alertas(Documento_Con_Celular_Correo, conn, Temporal)
    except Exception as e:
        print(f"Error al procesar las alertas: {e}")
        return

##################################################################################################################

    finally:
       conn.close()
       conn_test.close()
       conn_fraude.close()
       conn_riesgo.close()



       now = datetime.datetime.now()

       print(f"Alertas cargadas existosamente y conexión cerrada, Hora actual: {now}, Numero de registros en Alertas temporal: {len(alertas_temporal)}, Numero de registros en Alertas historico: {len(alertas_historico)}")
       texto_main = f"Hora actual: {now}, Numero de registros en Alertas temporal: {len(alertas_temporal)}, Numero de registros en Alertas historico: {len(alertas_historico)}"

    return texto_main





