import pandas as pd
pd.options.mode.chained_assignment=None
import pymssql


from parametros import usuario_400
from parametros import password_400
from parametros import ip_400




# def connect_to_database(server, database, user, password):
#     try:
#         conn = pymssql.connect(server=server, database=database, user=user, password=password)
#         print(f"OKAY: Conexión exitosa a la base de datos {database} en el servidor {server}")
#         return conn
#     except Exception as e:
#         raise Exception(f"ERROR: No se pudo establecer una conexión a la base de datos {database} en el servidor {server}: {e} archivo conexion_400")




# def conexion_fabogriesgo():
#     server_riesgo = "192.168.60.152:49505"
#     database_riesgo = "Productos y transaccionalidad"
#     user='UsrFraudes'
#     password='LeoMessi2023#'
#     conn_riesgo = connect_to_database(server_riesgo, database_riesgo, user, password)

#     return conn_riesgo



def connect_to_database(server, database, user, password):
    try:
        conn = pymssql.connect(host=server, user=user, password=password,
                               charset='UTF-8', database=database, tds_version=r'7.0')
        print(f"OKAY: Conexión exitosa a la base de datos {database} en el servidor {server}")
        return conn
    except Exception as e:
        raise Exception(f"ERROR: No se pudo establecer una conexión a la base de datos {database} en el servidor {server}: {e} archivo conexion_400")





def conexion_fabogriesgo():
    server_riesgo = ip_400
    database_riesgo = "Productos y transaccionalidad"
    # user='Usr_lkfraude'
    # password='Sq5q7v@K67nw'
    user = usuario_400
    password = password_400
    conn_riesgo = connect_to_database(server_riesgo, database_riesgo, user, password)

    return conn_riesgo