###1. Primer py, es la conexion a la bases SQL la funcion contiene las conexiones a la siguientes bases de datos
###1.1 conexion_fabogriesgo
###1.2 conexion_fabogsqlclu
###1.3 conexion_QA
# from  Uno_Conexion_a_SQL import conexion_fabogriesgo
#######################################################################################################################

import warnings
warnings.filterwarnings("ignore")

import time
from ordenado import main
from datetime import datetime
import logging

# Configuramos el logger
logging.basicConfig(filename='registro.log', level=logging.INFO, format='%(asctime)s %(message)s')
fechaciclo = datetime.now().strftime('%Y-%m-%d %H:%M:%S')

try:
    # Cargamos la mensajería

    # Ejecutamos la función main()
    texto_main=main()


    # Registramos la salida de la función main() junto con la fecha
    logging.info(f"La funcion main() se ejecuto correctamente en {time.strftime('%Y-%m-%d %H:%M:%S')} {texto_main}")

    # Esperamos 10 segundos
    for i in range(10):
        # print(f"Esperando {10-i} segundos... [{(i+1)*10}%]", end='\r')
        time.sleep(1)
    print(f"Ciclo finalizado,{fechaciclo}")

except Exception as e:
    # Registramos cualquier excepción que ocurra junto con la fecha
    logging.error(f"Error en la funcion main(): {e} en {time.strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"Error: {e}")
    print("Reintentando en 10 segundos...")
    time.sleep(10)


# pruebas en desarrollo
# import warnings
# warnings.filterwarnings("ignore")

# import time
# from ordenado import main
# import logging

# # Configuramos el logger
# logging.basicConfig(filename='registro.log', level=logging.INFO, format='%(asctime)s %(message)s')

# while True:
#     try:
#         # Cargamos la mensajería

#         # Ejecutamos la función main()
#         texto_main = main()

#         # Registramos la salida de la función main() junto con la fecha
#         logging.info(f"La funcion main() se ejecuto correctamente en {time.strftime('%Y-%m-%d %H:%M:%S')} {texto_main}")

#         # Esperamos 10 segundos
#         for i in range(10):
#             print(f"Esperando {10-i} segundos... [{(i+1)*10}%]", end='\r')
#             time.sleep(1)
#         print("Terminó la espera.")

#     except Exception as e:
#         # Registramos cualquier excepción que ocurra junto con la fecha
#         logging.error(f"Error en la funcion main(): {e} en {time.strftime('%Y-%m-%d %H:%M:%S')}")
#         print(f"Error: {e}")
#         print("Reintentando en 10 segundos...")
#         time.sleep(200)
