

import pandas as pd

from sqlalchemy import text
def obtener_alertas_numero_TDC(ALERTAS_NUMEROTDC, conn_riesgo):
    numero_tdc_con_comillas = ALERTAS_NUMEROTDC['CUENTA'].apply(lambda x: f"''{x}''")
    numero_tdc_coma_separada = ','.join(numero_tdc_con_comillas)

    
    SQL_QUERY_TDC = f"""
    SELECT * FROM openquery(DB2400_182, 'SELECT PAN, CUENTA FROM INTTARCRE.SATTARJET WHERE CUENTA IN ({numero_tdc_coma_separada})  AND CODBLQ = 0 ')
    """
    TDC = pd.read_sql((SQL_QUERY_TDC),conn_riesgo )
    TDC['PAN']=TDC['PAN'].str.strip()
    TDC['CUENTA']=TDC['CUENTA'].str.strip()
    TDC=TDC.dropna()


    TDC_BLOQUEO = pd.merge(ALERTAS_NUMEROTDC,TDC , left_on='CUENTA', right_on='CUENTA', how='left')


    return TDC_BLOQUEO
