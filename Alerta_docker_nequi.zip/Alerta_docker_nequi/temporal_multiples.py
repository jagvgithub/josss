# -*- coding: utf-8 -*-
"""
Created on Thu Mar 23 12:15:50 2023

@author: jesalvc
"""

from parametros import tabla_historica
from parametros import tabla_temporal
import pandas as pd
from sqlalchemy import text

def Temporal_Bloqueo(conn_test):
    # Alertas que se van a medir

    if conn_test:
        # Consulta a la tabla de categorías
        # query_temporal = "SELECT * FROM test.temporal"
        query_temporal = f"SELECT * FROM {tabla_temporal}"
        # query_historico = "SELECT * FROM test.historico_entradas"
        try:
            temporal_mysql = pd.read_sql(text(query_temporal), conn_test)
            # historica_mysql = pd.read_sql(text(query_historico), conn_test)
        except Exception as e:
            print(f"Error al ejecutar la consulta a la tabla de categorías: {e}")
    else:
        print("No se pudo establecer conexión con la base de datos de riesgo")


    return temporal_mysql





def historico_Bloqueo(conn_test):
    # Alertas que se van a medir

    if conn_test:
        # Consulta a la tabla de categorías

        # query_historico = "SELECT * FROM test.historico"
        query_historico = f"SELECT * FROM {tabla_historica}"
        try:

            historica_mysql = pd.read_sql(text(query_historico), conn_test)
        except Exception as e:
            print(f"Error al ejecutar la consulta a la tabla de categorías: {e}")
    else:
        print("No se pudo establecer conexión con la base de datos de riesgo")


    return historica_mysql


