import pandas as pd
from sqlalchemy import text



import pandas as pd

def obtener_celular_correo(Documento_Con_TDC, conn_riesgo):
    tamano_lote = 100  # Tamaño fijo del lote

    # Dividir la lista de documentos en lotes más pequeños
    lotes_documentos = [Documento_Con_TDC['Documento'][i:i + tamano_lote] for i in range(0, len(Documento_Con_TDC['Documento']), tamano_lote)]

    # Lista para almacenar los resultados
    resultados = []

    # Iterar sobre los lotes de documentos
    for lote_documentos in lotes_documentos:
        documentos_con_comillas = lote_documentos.apply(lambda x: f"''{x}''")
        documentos_coma_separada = ','.join(documentos_con_comillas)

        # Construir la consulta SQL
        SQL_QUERY_DATOS = f"""SELECT * FROM OPENQUERY(DB2400_182, 'select A.CUSSNR as Documento, A.cuna1 as nombrecup, A.CUEMA1 as Correo_Nuevo, A.CUCLPH as Numero_Nuevo, UPPER(B.CUCLNM) as Nombre_Completo 
                              from BNKPRD01.CUP003 AS A 
                              LEFT JOIN BNKPRD01.CUP004 AS B 
                              ON A.CUNBR = B.CUCNBR where A.CUSSNR IN({documentos_coma_separada})')"""

        # Ejecutar la consulta SQL y agregar los resultados al lista de resultados
        datos_nuevos = pd.read_sql(SQL_QUERY_DATOS, conn_riesgo)
        resultados.append(datos_nuevos)

    # Combinar todos los resultados
    datos_nuevos = pd.concat(resultados, ignore_index=True)

    # Resto del código sigue igual...
    datos_nuevos['DOCUMENTO'] = datos_nuevos['DOCUMENTO'].astype(int)
    datos_nuevos['DOCUMENTO'] = datos_nuevos['DOCUMENTO'].astype(str)
    datos_nuevos['DOCUMENTO'] = datos_nuevos['DOCUMENTO'].str.strip()
    datos_nuevos['CORREO_NUEVO'] = datos_nuevos['CORREO_NUEVO'].str.strip()
    datos_nuevos['NOMBRE_COMPLETO'].fillna(datos_nuevos['NOMBRECUP'], inplace=True)
    datos_nuevos.drop(columns=['NOMBRECUP'], inplace=True)
    datos_nuevos['primer_nombre'] = datos_nuevos['NOMBRE_COMPLETO'].astype(str).apply(lambda x: x.split()[0] if pd.notnull(x) and len(x.split()) > 0 else '')

    Documento_Con_TDC['Documento'] = Documento_Con_TDC['Documento'].astype(str)

    alerta_numero_tarjeta_datos_nuevos = pd.merge(Documento_Con_TDC, datos_nuevos, left_on='Documento', right_on='DOCUMENTO', how='left')

    alerta_numero_tarjeta_datos_nuevos = alerta_numero_tarjeta_datos_nuevos.drop(["DOCUMENTO"], axis=1)

    return alerta_numero_tarjeta_datos_nuevos
