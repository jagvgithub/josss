



import pandas as pd
from sqlalchemy import text
from parametros import base



def Codigo111(conn_riesgo):
    # if not conn_riesgo:
    #     print("No se pudo establecer conexión con la base de datos de riesgo")
    #     return None


    query_horas = f"SELECT * FROM {base}.horas_atras"
    df_horas = pd.read_sql(text(query_horas), conn_riesgo)
    horas_atras = df_horas.at[0, 'Horas_Atras']

    query_base111=f"""SELECT * FROM BFFR4UD.Envio
    where Estrategia = 'BloqueoFraudeEstado111'
    AND Fecha >= DATE_SUB(NOW(), INTERVAL {horas_atras} HOUR)  order by fecha desc
    """

    try:
        base_Fraude_111 = pd.read_sql(text(query_base111), conn_riesgo)
    except Exception as e:
        print(f"Error al ejecutar la consulta a la tabla de who is who: {e}")
        return None


    nombres_columnas = {
    'Fecha': 'Fecha_Fraude911',
    'Id': 'Id_Fraude911',
    'Documento': 'Documento_Fraude911',
    'Nombre': 'Nombre_Fraude911',
    'Estrategia': 'Estrategia_Fraude911'}
    base_Fraude_111 = base_Fraude_111.rename(columns=nombres_columnas)
    return base_Fraude_111
